busca = input()
quant = int(input())
nomes = []


for x in range(quant):
    nome, sobrenome = input().split()
    nomes.append([nome, sobrenome])

for nome in nomes:
    for x in range(len(busca)):
        primeiraparte = busca[:x]
        segundaparte = busca[x:]

        if primeiraparte == "":
            if nome[0].startswith(segundaparte) or nome[1].startswith(segundaparte):
                print(nome[0], nome[1])
                break
        else:
            if nome[0].startswith(primeiraparte) and nome[1].startswith(segundaparte):
                print(nome[0], nome[1])
                break





