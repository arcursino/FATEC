/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pacote;

/**
 *
 * @author Aluno
 */
public class Funcionario extends Pessoa{
    double salario;

    public Funcionario(double salario, String RG, String nome) {
        super(RG, nome);
        this.salario = salario;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    
    public double aumentar_Salario(double percentual){
        return salario +(salario * percentual);
    }
}
