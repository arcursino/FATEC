/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pacote;

/**
 *
 * @author Aluno
 */
public class ProjFuncionario {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Funcionario funcionario1, funcionario2;
                
        funcionario1 = new Funcionario(3500.00,"41414141", "Fulano1");
        funcionario2 = new Funcionario(2500.00,"42424242", "Fulano2");
                
       
                
        System.out.println("Nome do Funcionário: " + funcionario1.nome);
        System.out.println("Salário atual: " + funcionario1.salario);
        System.out.println("Salário com o aumento: " + funcionario1.aumentar_Salario(0.10));
        
        System.out.println("Nome do Funcionário: " + funcionario2.nome);
        System.out.println("Salário atual: " + funcionario2.salario);
        System.out.println("Salário com o aumento: " + funcionario2.aumentar_Salario(0.30));  
    }  
}
